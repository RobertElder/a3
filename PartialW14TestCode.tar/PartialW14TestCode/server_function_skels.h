/*
 * server_function_skels.h
 *
 * This file defines the corresponding skeletons for server functions.
 */

int f0_Skel(int* a, void** b);
int f1_Skel(int* a, void** b);
int f2_Skel(int* a, void** b);
int f3_Skel(int* a, void** b);
int f4_Skel(int* a, void** b);
